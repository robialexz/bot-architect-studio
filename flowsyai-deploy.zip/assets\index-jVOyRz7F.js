function t(t,[a,n]){return Math.min(n,Math.max(a,t))}export{t as c};
